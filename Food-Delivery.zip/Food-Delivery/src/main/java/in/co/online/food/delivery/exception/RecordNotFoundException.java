package in.co.online.food.delivery.exception;

public class RecordNotFoundException extends Exception
{
	
	public RecordNotFoundException(String msg) {
		super(msg);
	}
}
