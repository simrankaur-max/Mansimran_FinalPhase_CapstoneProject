package in.co.online.food.delivery.dto;


public interface DropdownList
{
	public String getKey();

	public String getValue();
}
